import {atom} from 'jotai'

export const isLogin = atom(false)
export const session = atom('')